leaflet-dvf Contributors
==================

Leaflet DVF is made possible by contributions from:

* Scott Fairgrieve [sfairgrieve](https://github.com/sfairgrieve)
* Keith Chew [keithchew](https://github.com/keithchew)
* Jeff Meadows [Jeff-Meadows](https://github.com/Jeff-Meadows)
* Rob Story [wrobstory](https://github.com/wrobstory)
* Glen Robertson [glenrobertson](https://github.com/glenrobertson)
* Jelle Victoor [JelleConundra](https://github.com/JelleConundra)
* Patrick Doody [go0ty](https://github.com/go0ty)